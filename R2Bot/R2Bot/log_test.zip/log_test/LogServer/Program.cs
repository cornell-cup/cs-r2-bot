﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace LogServer
{
    class Program
    {
        static void Main(String[] args)
        {
            Server.createServer("Ping");
        }
    }
}