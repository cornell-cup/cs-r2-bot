#pragma once
#include <string>
#include "Ice/Ice.h"
#include "Logging.h"

class Client
{
public:
	Client(void);
	~Client(void);
	Logging::RemoteLogPrx createClient(std::string, std::string, std::string);
	void setRemoteLogPrx(Logging::RemoteLogPrx);
	void logMessage(std::string, std::string, std::string);
};

